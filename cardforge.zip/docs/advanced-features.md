# أفكار ميزات متقدمة (مستقبلية)

## Export: PDF + Print Sheets
- دمج عدة بطاقات في صفحة واحدة (A4 / Letter)
- هوامش، قصّ (Bleed)، وعلامات قصّ (Crop marks)

## Undo/Redo
- Command stack (immutable snapshots) أو patch-based history
- قيود للذاكرة (history limit)

## Asset Library
- تخزين الصور خارج المشروع + hash dedup
- Tags + search + folders
- Auto embed option

## Plugins
- Renderers: Canvas/WebGL/SVG
- Exporters: PNG/SVG/PDF
- Importers: CSV/JSON/Google Sheets

## Text rules
- Auto-fit
- Overflow policies: shrink, wrap, ellipsis
