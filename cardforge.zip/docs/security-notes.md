# ملاحظات أمان (Electron)

- تم تفعيل:
  - `contextIsolation: true`
  - `nodeIntegration: false`
  - `sandbox: true`
- الـ IPC محصور في عمليات فتح/حفظ وكتابة ملفات، بدون تنفيذ أوامر نظام.

مستقبلاً:
- تقييد المسارات في writeBinary/writeText (اختياري)
- إضافة تحقق على حجم الملفات (خصوصاً الصور)
