import { execSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';

execSync('tsc -p tsconfig.json', { stdio: 'inherit' });

// Convert ESM outputs to CJS wrappers for Electron compatibility.
const distDir = path.join(process.cwd(), 'dist');

const wrapToCjs = (esmFile, cjsFile) => {
  const code = readFileSync(path.join(distDir, esmFile), 'utf-8');
  // Simple heuristic: replace 'export' re-exports with require wrapper.
  // For MVP we generate explicit CommonJS entrypoints.
  const cjs =
`// Auto-generated wrapper (CJS) for Electron
const mod = await import('./${esmFile}');
module.exports = mod;
`;
  writeFileSync(path.join(distDir, cjsFile), cjs, 'utf-8');
};

wrapToCjs('main.js', 'main.cjs');
wrapToCjs('preload.js', 'preload.cjs');
