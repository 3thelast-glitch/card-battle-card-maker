import { app, BrowserWindow, ipcMain, dialog } from 'electron';
import path from 'node:path';
import fs from 'node:fs/promises';

const isDev = !app.isPackaged;

function createWindow() {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    backgroundColor: '#0b0f19',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  if (isDev) {
    // Vite dev server
    win.loadURL('http://localhost:5173');
    win.webContents.openDevTools({ mode: 'detach' });
  } else {
    const indexHtml = path.join(__dirname, '../../renderer/dist/index.html');
    win.loadFile(indexHtml);
  }
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

/** IPC: dialogs */
ipcMain.handle('dialog:openProject', async () => {
  const result = await dialog.showOpenDialog({
    title: 'Open CardForge Project',
    filters: [{ name: 'CardForge Project', extensions: ['cforge.json'] }],
    properties: ['openFile'],
  });
  return result;
});

ipcMain.handle('dialog:saveProject', async () => {
  const result = await dialog.showSaveDialog({
    title: 'Save CardForge Project',
    defaultPath: 'project.cforge.json',
    filters: [{ name: 'CardForge Project', extensions: ['cforge.json'] }],
  });
  return result;
});

/** IPC: file IO */
ipcMain.handle('fs:writeTextFile', async (_evt, { filePath, text }: { filePath: string; text: string }) => {
  await fs.writeFile(filePath, text, 'utf-8');
  return { ok: true };
});

ipcMain.handle('fs:readTextFile', async (_evt, { filePath }: { filePath: string }) => {
  const text = await fs.readFile(filePath, 'utf-8');
  return { ok: true, text };
});

ipcMain.handle('fs:writeBinaryFile', async (_evt, { filePath, data }: { filePath: string; data: ArrayBuffer }) => {
  const buf = Buffer.from(new Uint8Array(data));
  await fs.writeFile(filePath, buf);
  return { ok: true };
});

ipcMain.handle('app:paths', async () => {
  return {
    userData: app.getPath('userData'),
    documents: app.getPath('documents'),
  };
});
