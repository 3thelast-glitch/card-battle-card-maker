import { contextBridge, ipcRenderer } from 'electron';

export type SaveDialogResult = { canceled: boolean; filePath?: string };

contextBridge.exposeInMainWorld('cardforge', {
  openProjectDialog: () => ipcRenderer.invoke('dialog:openProject'),
  saveProjectDialog: () => ipcRenderer.invoke('dialog:saveProject'),
  writeTextFile: (filePath: string, text: string) =>
    ipcRenderer.invoke('fs:writeTextFile', { filePath, text }),
  writeBinaryFile: (filePath: string, data: ArrayBuffer) =>
    ipcRenderer.invoke('fs:writeBinaryFile', { filePath, data }),
  readTextFile: (filePath: string) => ipcRenderer.invoke('fs:readTextFile', { filePath }),
  appPaths: () => ipcRenderer.invoke('app:paths'),
});
