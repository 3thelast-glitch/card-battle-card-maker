/// <reference types="vite/client" />

declare global {
  interface Window {
    cardforge?: {
      openProjectDialog: () => Promise<{ canceled: boolean; filePaths?: string[] }>;
      saveProjectDialog: () => Promise<{ canceled: boolean; filePath?: string }>;
      writeTextFile: (filePath: string, text: string) => Promise<{ ok: boolean }>;
      readTextFile: (filePath: string) => Promise<{ ok: boolean; text: string }>;
      writeBinaryFile: (filePath: string, data: ArrayBuffer) => Promise<{ ok: boolean }>;
      appPaths: () => Promise<{ userData: string; documents: string }>;
    };
  }
}

export {};
