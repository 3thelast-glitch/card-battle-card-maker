import React, { useEffect, useMemo, useRef } from 'react';
import { Stage, Layer, Rect, Text, Image as KonvaImage, Transformer } from 'react-konva';
import Konva from 'konva';
import { ElementModel, Template } from '@cardforge/core';

type Props = {
  template: Template;
  elements: ElementModel[];
  selectedId: string | null;
  gridSize: number;
  onSelect: (id: string | null) => void;
  onChange: (elements: ElementModel[]) => void;
};

export function CardCanvas(props: Props) {
  const stageRef = useRef<Konva.Stage>(null);
  const trRef = useRef<Konva.Transformer>(null);

  // Export hook for parent
  useEffect(() => {
    (window as any).__cardforge_export = (opts?: { pixelRatio?: number }) => {
      const stage = stageRef.current;
      if (!stage) return undefined;
      return stage.toDataURL({ pixelRatio: opts?.pixelRatio ?? 1 });
    };
    return () => { delete (window as any).__cardforge_export; };
  }, []);

  const selectedNode = useMemo(() => {
    const stage = stageRef.current;
    if (!stage || !props.selectedId) return null;
    return stage.findOne(`#${props.selectedId}`) as Konva.Node | null;
  }, [props.selectedId, props.elements]);

  useEffect(() => {
    const tr = trRef.current;
    if (!tr) return;
    if (selectedNode) {
      tr.nodes([selectedNode]);
      tr.getLayer()?.batchDraw();
    } else {
      tr.nodes([]);
      tr.getLayer()?.batchDraw();
    }
  }, [selectedNode]);

  const snap = (v: number) => Math.round(v / props.gridSize) * props.gridSize;

  const updateById = (id: string, patch: Partial<ElementModel>) => {
    props.onChange(props.elements.map((e) => (e.id === id ? { ...e, ...patch } : e)));
  };

  const size = props.template.size;

  return (
    <div style={{ width: size.w + 40, height: size.h + 40, display: 'grid', placeItems: 'center' }}>
      <Stage
        width={size.w}
        height={size.h}
        ref={stageRef}
        onMouseDown={(e) => {
          const clickedOnEmpty = e.target === e.target.getStage();
          if (clickedOnEmpty) props.onSelect(null);
        }}
        style={{
          borderRadius: 16,
          boxShadow: '0 14px 50px rgba(0,0,0,.55)',
          background: '#0d1424',
          border: '1px solid rgba(255,255,255,.08)',
        }}
      >
        {/* Grid */}
        <Layer listening={false}>
          {renderGrid(size.w, size.h, props.gridSize)}
        </Layer>

        {/* Card background */}
        <Layer listening={false}>
          <Rect x={0} y={0} width={size.w} height={size.h} fill={props.template.background ?? '#0e1830'} cornerRadius={18} />
        </Layer>

        {/* Elements */}
        <Layer>
          {props.elements.map((el) => {
            if (!el.visible) return null;

            if (el.type === 'rect') {
              return (
                <Rect
                  key={el.id}
                  id={el.id}
                  x={el.x}
                  y={el.y}
                  width={el.width}
                  height={el.height}
                  rotation={el.rotation}
                  fill={el.fill ?? '#1f2a44'}
                  stroke={el.stroke ?? '#3b5b8a'}
                  strokeWidth={el.strokeWidth ?? 2}
                  cornerRadius={el.radius ?? 0}
                  draggable
                  onClick={() => props.onSelect(el.id)}
                  onTap={() => props.onSelect(el.id)}
                  onDragEnd={(e) => updateById(el.id, { x: snap(e.target.x()), y: snap(e.target.y()) })}
                  onTransformEnd={(e) => {
                    const node = e.target as Konva.Rect;
                    const scaleX = node.scaleX();
                    const scaleY = node.scaleY();
                    node.scaleX(1);
                    node.scaleY(1);
                    updateById(el.id, {
                      x: snap(node.x()),
                      y: snap(node.y()),
                      width: Math.max(10, node.width() * scaleX),
                      height: Math.max(10, node.height() * scaleY),
                      rotation: node.rotation(),
                    });
                  }}
                />
              );
            }

            if (el.type === 'text') {
              return (
                <Text
                  key={el.id}
                  id={el.id}
                  x={el.x}
                  y={el.y}
                  width={el.width}
                  height={el.height}
                  rotation={el.rotation}
                  text={el.text ?? ''}
                  fontSize={el.fontSize ?? 32}
                  fontFamily={el.fontFamily ?? 'serif'}
                  fill={el.fill ?? '#fff'}
                  align={el.align ?? 'center'}
                  verticalAlign="middle"
                  draggable
                  onClick={() => props.onSelect(el.id)}
                  onTap={() => props.onSelect(el.id)}
                  onDragEnd={(e) => updateById(el.id, { x: snap(e.target.x()), y: snap(e.target.y()) })}
                  onTransformEnd={(e) => {
                    const node = e.target as Konva.Text;
                    const scaleX = node.scaleX();
                    const scaleY = node.scaleY();
                    node.scaleX(1);
                    node.scaleY(1);
                    updateById(el.id, {
                      x: snap(node.x()),
                      y: snap(node.y()),
                      width: Math.max(10, node.width() * scaleX),
                      height: Math.max(10, node.height() * scaleY),
                      rotation: node.rotation(),
                    });
                  }}
                />
              );
            }

            if (el.type === 'image') {
              return <ImageNode key={el.id} el={el} selected={props.selectedId === el.id} onSelect={props.onSelect} onUpdate={updateById} snap={snap} />;
            }

            return null;
          })}

          <Transformer
            ref={trRef}
            rotateEnabled
            enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']}
            borderStroke="rgba(94,234,212,.8)"
            anchorStroke="rgba(94,234,212,.9)"
            anchorFill="rgba(0,0,0,.8)"
            anchorSize={10}
          />
        </Layer>
      </Stage>
    </div>
  );
}

function renderGrid(w: number, h: number, step: number) {
  const lines: React.ReactNode[] = [];
  for (let x = step; x < w; x += step) {
    lines.push(<Rect key={'vx' + x} x={x} y={0} width={1} height={h} fill="rgba(255,255,255,.04)" />);
  }
  for (let y = step; y < h; y += step) {
    lines.push(<Rect key={'hy' + y} x={0} y={y} width={w} height={1} fill="rgba(255,255,255,.04)" />);
  }
  return lines;
}

function useHtmlImage(src: string | undefined) {
  const [img, setImg] = React.useState<HTMLImageElement | null>(null);
  useEffect(() => {
    if (!src) return;
    const i = new window.Image();
    i.crossOrigin = 'anonymous';
    i.onload = () => setImg(i);
    i.src = src;
  }, [src]);
  return img;
}

function ImageNode(props: {
  el: ElementModel;
  selected: boolean;
  onSelect: (id: string) => void;
  onUpdate: (id: string, patch: Partial<ElementModel>) => void;
  snap: (v: number) => number;
}) {
  const img = useHtmlImage((props.el as any).src);
  const el = props.el as any;

  return (
    <KonvaImage
      id={el.id}
      x={el.x}
      y={el.y}
      width={el.width}
      height={el.height}
      rotation={el.rotation}
      image={img ?? undefined}
      draggable
      onClick={() => props.onSelect(el.id)}
      onTap={() => props.onSelect(el.id)}
      onDragEnd={(e) => props.onUpdate(el.id, { x: props.snap(e.target.x()), y: props.snap(e.target.y()) })}
      onTransformEnd={(e) => {
        const node = e.target as Konva.Image;
        const scaleX = node.scaleX();
        const scaleY = node.scaleY();
        node.scaleX(1);
        node.scaleY(1);
        props.onUpdate(el.id, {
          x: props.snap(node.x()),
          y: props.snap(node.y()),
          width: Math.max(10, node.width() * scaleX),
          height: Math.max(10, node.height() * scaleY),
          rotation: node.rotation(),
        });
      }}
    />
  );
}
