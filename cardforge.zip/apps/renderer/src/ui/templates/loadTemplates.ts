import { Template } from '@cardforge/core';
// Vite can import JSON at build-time
import fantasy from '../../../../templates/fantasy-basic.json';
import blank from '../../../../templates/blank.json';

export function loadBuiltInTemplates(): Template[] {
  return [fantasy as Template, blank as Template];
}
