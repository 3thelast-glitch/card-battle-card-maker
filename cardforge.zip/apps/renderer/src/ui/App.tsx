import React, { useMemo, useState } from 'react';
import { Home } from './screens/Home';
import { TemplatePicker } from './screens/TemplatePicker';
import { EditorScreen } from './screens/EditorScreen';
import { Project, Template } from '@cardforge/core';
import { loadBuiltInTemplates } from './templates/loadTemplates';
import { createEmptyProjectFromTemplate } from '@cardforge/core';
import { storage } from '@cardforge/storage';

type Screen = 'home' | 'templates' | 'editor';

export function App() {
  const templates = useMemo(() => loadBuiltInTemplates(), []);
  const [screen, setScreen] = useState<Screen>('home');
  const [project, setProject] = useState<Project | null>(null);

  const openProject = async () => {
    const api = window.cardforge;
    if (!api) {
      alert('This build is missing preload API.');
      return;
    }
    const picked = await api.openProjectDialog();
    if (picked.canceled || !picked.filePaths?.[0]) return;

    const res = await api.readTextFile(picked.filePaths[0]);
    if (!res.ok) return;

    const loaded = storage.parseProject(res.text);
    loaded.meta.filePath = picked.filePaths[0];
    setProject(loaded);
    setScreen('editor');
  };

  const newProject = () => setScreen('templates');

  const chooseTemplate = (tpl: Template) => {
    const p = createEmptyProjectFromTemplate(tpl);
    setProject(p);
    setScreen('editor');
  };

  const backToHome = () => {
    setProject(null);
    setScreen('home');
  };

  if (screen === 'home') {
    return <Home onNew={newProject} onOpen={openProject} />;
  }
  if (screen === 'templates') {
    return <TemplatePicker templates={templates} onPick={chooseTemplate} onBack={backToHome} />;
  }
  if (!project) return null;

  return (
    <EditorScreen
      templates={templates}
      project={project}
      onProjectChange={setProject}
      onExit={backToHome}
    />
  );
}
