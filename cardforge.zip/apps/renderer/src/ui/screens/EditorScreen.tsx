import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Button, Divider, Input, Label, Panel, Row } from '../components/Ui';
import { Project, Template, applyBindingsToElements, clamp, createId, ElementModel } from '@cardforge/core';
import { storage } from '@cardforge/storage';
import { CardCanvas } from '../widgets/CardCanvas';
import Papa from 'papaparse';

type BatchRow = Record<string, any>;

export function EditorScreen(props: {
  templates: Template[];
  project: Project;
  onProjectChange: (p: Project) => void;
  onExit: () => void;
}) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('جاهز');
  const [grid, setGrid] = useState<number>(10);

  const template = useMemo(
    () => props.templates.find((t) => t.id === props.project.templateId) ?? props.templates[0],
    [props.project.templateId, props.templates],
  );

  const selected = useMemo(
    () => props.project.elements.find((e) => e.id === selectedId) ?? null,
    [props.project.elements, selectedId],
  );

  // Keyboard shortcuts (basic)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const isCmd = e.ctrlKey || e.metaKey;
      if (isCmd && e.key.toLowerCase() === 's') {
        e.preventDefault();
        void saveProject();
      }
      if (isCmd && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        if (!selected) return;
        const dup: ElementModel = { ...selected, id: createId(), x: selected.x + 16, y: selected.y + 16, name: selected.name + ' (copy)' };
        props.onProjectChange({ ...props.project, elements: [...props.project.elements, dup] });
        setSelectedId(dup.id);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [props.project, selected, props.onProjectChange]);

  const updateElement = (patch: Partial<ElementModel>) => {
    if (!selected) return;
    const next = props.project.elements.map((e) => (e.id === selected.id ? { ...e, ...patch } : e));
    props.onProjectChange({ ...props.project, elements: next });
  };

  const addText = () => {
    const e: ElementModel = {
      id: createId(),
      type: 'text',
      name: 'Text',
      x: 80,
      y: 80,
      width: 320,
      height: 60,
      rotation: 0,
      visible: true,
      text: 'New Card Title',
      fontSize: 36,
      fontFamily: 'serif',
      fill: '#ffffff',
      align: 'center',
      bindingKey: '',
    };
    props.onProjectChange({ ...props.project, elements: [...props.project.elements, e] });
    setSelectedId(e.id);
  };

  const addRect = () => {
    const e: ElementModel = {
      id: createId(),
      type: 'rect',
      name: 'Rect',
      x: 90,
      y: 160,
      width: 360,
      height: 180,
      rotation: 0,
      visible: true,
      fill: '#1f2a44',
      stroke: '#3b5b8a',
      strokeWidth: 2,
      radius: 14,
      bindingKey: '',
    };
    props.onProjectChange({ ...props.project, elements: [...props.project.elements, e] });
    setSelectedId(e.id);
  };

  const addImage = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      const dataUrl = await fileToDataUrl(file);
      const e: ElementModel = {
        id: createId(),
        type: 'image',
        name: 'Image',
        x: 80,
        y: 260,
        width: 320,
        height: 220,
        rotation: 0,
        visible: true,
        src: dataUrl,
        crop: null,
        bindingKey: '',
      };
      props.onProjectChange({ ...props.project, elements: [...props.project.elements, e] });
      setSelectedId(e.id);
    };
    input.click();
  };

  const reorder = (id: string, dir: 'up' | 'down') => {
    const idx = props.project.elements.findIndex((e) => e.id === id);
    if (idx < 0) return;
    const arr = [...props.project.elements];
    const target = dir === 'up' ? idx - 1 : idx + 1;
    if (target < 0 || target >= arr.length) return;
    const [it] = arr.splice(idx, 1);
    arr.splice(target, 0, it);
    props.onProjectChange({ ...props.project, elements: arr });
  };

  const toggleVisible = (id: string) => {
    props.onProjectChange({
      ...props.project,
      elements: props.project.elements.map((e) => (e.id === id ? { ...e, visible: !e.visible } : e)),
    });
  };

  const saveProject = async () => {
    const api = window.cardforge;
    if (!api) {
      setStatus('لا يوجد API للحفظ.');
      return;
    }

    let filePath = props.project.meta.filePath;
    if (!filePath) {
      const picked = await api.saveProjectDialog();
      if (picked.canceled || !picked.filePath) return;
      filePath = picked.filePath;
    }

    const toSave = { ...props.project, meta: { ...props.project.meta, filePath } };
    const text = storage.stringifyProject(toSave);
    await api.writeTextFile(filePath, text);
    props.onProjectChange(toSave);
    setStatus('تم الحفظ ✓');
    setTimeout(() => setStatus('جاهز'), 1200);
  };

  const exportPng = async () => {
    setStatus('تصدير PNG...');
    // renderer does export; it requests a path then writes binary
    const api = window.cardforge;
    if (!api) return;

    const picked = await api.saveProjectDialog();
    if (picked.canceled || !picked.filePath) return;

    // We'll export a PNG next to chosen json by replacing extension
    const outPath = picked.filePath.replace(/\.cforge\.json$/i, '') + '.png';
    const dataUrl = (window as any).__cardforge_export?.() as string | undefined;
    if (!dataUrl) {
      setStatus('تعذر التصدير: Stage غير جاهز');
      return;
    }
    const buf = dataUrlToArrayBuffer(dataUrl);
    await api.writeBinaryFile(outPath, buf);
    setStatus('تم تصدير PNG ✓');
    setTimeout(() => setStatus('جاهز'), 1200);
  };

  const importCsvAndBatchExport = async () => {
    const api = window.cardforge;
    if (!api) return;

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,application/json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;

      const text = await file.text();
      let rows: BatchRow[] = [];

      if (file.name.toLowerCase().endsWith('.csv')) {
        const parsed = Papa.parse<BatchRow>(text, { header: true, skipEmptyLines: true });
        rows = (parsed.data ?? []).filter(Boolean);
      } else {
        const parsed = JSON.parse(text);
        rows = Array.isArray(parsed) ? parsed : parsed.rows ?? [];
      }

      if (!rows.length) {
        alert('الملف فارغ أو غير صالح.');
        return;
      }

      // choose output folder by asking for a "save" file, then use its folder
      const picked = await api.saveProjectDialog();
      if (picked.canceled || !picked.filePath) return;
      const folder = picked.filePath.split(/\\|\//).slice(0, -1).join('/');

      setStatus(`Batch Export: ${rows.length} بطاقة...`);

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const bound = applyBindingsToElements(props.project.elements, row);
        props.onProjectChange({ ...props.project, elements: bound });

        // allow Konva to re-render
        await sleep(30);

        const dataUrl = (window as any).__cardforge_export?.({ pixelRatio: 2 }) as string | undefined;
        if (!dataUrl) continue;

        const filename = sanitizeFileName(row.name ?? row.title ?? `card_${i + 1}`) + '.png';
        const outPath = `${folder}/${filename}`;
        const buf = dataUrlToArrayBuffer(dataUrl);
        await api.writeBinaryFile(outPath, buf);

        setStatus(`Batch Export: ${i + 1}/${rows.length}`);
      }

      setStatus('Batch Export اكتمل ✓');
      setTimeout(() => setStatus('جاهز'), 1400);
    };

    input.click();
  };

  // Canvas update handler (drag/transform)
  const onElementsChange = useCallback((elements: ElementModel[]) => {
    props.onProjectChange({ ...props.project, elements });
  }, [props.project, props.onProjectChange]);

  return (
    <div style={{
      height: '100vh',
      display: 'grid',
      gridTemplateRows: '54px 1fr 34px',
      background: 'linear-gradient(180deg, rgba(94,234,212,.06), rgba(0,0,0,0) 30%)',
    }}>
      {/* Topbar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 14px',
        borderBottom: '1px solid var(--line)',
        background: 'rgba(0,0,0,.18)',
        backdropFilter: 'blur(10px)',
      }}>
        <Row gap={10}>
          <div style={{ fontWeight: 800, letterSpacing: .2 }}>CardForge</div>
          <div style={{ color: 'var(--muted)', fontSize: 13 }}>Template: {template?.name}</div>
        </Row>
        <Row gap={10}>
          <Button variant="ghost" onClick={props.onExit}>خروج</Button>
          <Button variant="ghost" onClick={exportPng}>Export PNG</Button>
          <Button onClick={saveProject}>حفظ <span className="kbd" style={{ marginLeft: 8 }}>Ctrl</span><span className="kbd">S</span></Button>
        </Row>
      </div>

      {/* Main layout */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '280px 1fr 320px',
        gap: 14,
        padding: 14,
        minHeight: 0,
      }}>
        {/* Left panel */}
        <div style={{ display: 'grid', gap: 14, minHeight: 0 }}>
          <Panel title="العناصر">
            <div style={{ display: 'grid', gap: 10 }}>
              <Button onClick={addText}>+ Text</Button>
              <Button onClick={addRect} variant="ghost">+ Shape (Rect)</Button>
              <Button onClick={addImage} variant="ghost">+ Image</Button>
              <Divider />
              <Button onClick={importCsvAndBatchExport} variant="primary">Batch Export (CSV/JSON)</Button>
            </div>
          </Panel>

          <Panel title="الطبقات (Layers)">
            <div style={{ display: 'grid', gap: 8 }}>
              {props.project.elements.map((e, idx) => {
                const active = e.id === selectedId;
                return (
                  <div key={e.id} style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr auto auto auto',
                    gap: 8,
                    padding: 8,
                    borderRadius: 12,
                    border: '1px solid ' + (active ? 'rgba(94,234,212,.45)' : 'var(--line)'),
                    background: active ? 'rgba(94,234,212,.08)' : 'rgba(255,255,255,.02)',
                    cursor: 'pointer',
                    alignItems: 'center',
                  }} onClick={() => setSelectedId(e.id)}>
                    <div style={{ fontSize: 13 }}>
                      <div style={{ fontWeight: 650 }}>{e.name}</div>
                      <div style={{ color: 'var(--muted)', fontSize: 12 }}>{e.type}</div>
                    </div>
                    <button title="إظهار/إخفاء" onClick={(ev) => { ev.stopPropagation(); toggleVisible(e.id); }}
                      style={iconBtnStyle}>{e.visible ? '👁️' : '🚫'}</button>
                    <button title="أعلى" onClick={(ev) => { ev.stopPropagation(); reorder(e.id, 'up'); }}
                      style={iconBtnStyle}>↑</button>
                    <button title="أسفل" onClick={(ev) => { ev.stopPropagation(); reorder(e.id, 'down'); }}
                      style={iconBtnStyle}>↓</button>
                  </div>
                );
              })}
              {!props.project.elements.length ? (
                <div style={{ color: 'var(--muted)', lineHeight: 1.6 }}>
                  لا توجد عناصر بعد. أضف Text أو Shape أو Image من الأعلى.
                </div>
              ) : null}
            </div>
          </Panel>
        </div>

        {/* Canvas */}
        <Panel title="Canvas">
          <div style={{ display: 'grid', gap: 10 }}>
            <Row gap={10}>
              <div style={{ color: 'var(--muted)', fontSize: 12 }}>Grid</div>
              <div style={{ width: 120 }}>
                <Input type="number" value={grid} min={2} max={64} onChange={(e) => setGrid(clamp(Number(e.target.value), 2, 64))} />
              </div>
              <div style={{ color: 'var(--muted)', fontSize: 12 }}>Snap-to-grid</div>
            </Row>

            <div style={{ display: 'grid', placeItems: 'center', padding: 10 }}>
              <CardCanvas
                template={template}
                elements={props.project.elements}
                selectedId={selectedId}
                gridSize={grid}
                onSelect={setSelectedId}
                onChange={onElementsChange}
              />
            </div>
          </div>
        </Panel>

        {/* Properties */}
        <Panel title="الخصائص (Properties)">
          {!selected ? (
            <div style={{ color: 'var(--muted)', lineHeight: 1.7 }}>
              اختر عنصراً من Canvas أو من قائمة Layers لعرض خصائصه.
              <div style={{ marginTop: 10 }}>
                تلميح: اكتب في Text مثل <code>{{'{{name}}'}}</code> لربطه بالبيانات في Batch Export.
              </div>
            </div>
          ) : (
            <div style={{ display: 'grid', gap: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 750 }}>{selected.name}</div>

              <div>
                <Label>الاسم</Label>
                <Input value={selected.name} onChange={(e) => updateElement({ name: e.target.value })} />
              </div>

              <Row gap={10}>
                <div style={{ flex: 1 }}>
                  <Label>X</Label>
                  <Input type="number" value={selected.x} onChange={(e) => updateElement({ x: Number(e.target.value) })} />
                </div>
                <div style={{ flex: 1 }}>
                  <Label>Y</Label>
                  <Input type="number" value={selected.y} onChange={(e) => updateElement({ y: Number(e.target.value) })} />
                </div>
              </Row>

              <Row gap={10}>
                <div style={{ flex: 1 }}>
                  <Label>W</Label>
                  <Input type="number" value={selected.width} onChange={(e) => updateElement({ width: Math.max(10, Number(e.target.value)) })} />
                </div>
                <div style={{ flex: 1 }}>
                  <Label>H</Label>
                  <Input type="number" value={selected.height} onChange={(e) => updateElement({ height: Math.max(10, Number(e.target.value)) })} />
                </div>
              </Row>

              {'rotation' in selected ? (
                <div>
                  <Label>Rotation</Label>
                  <Input type="number" value={selected.rotation} onChange={(e) => updateElement({ rotation: Number(e.target.value) })} />
                </div>
              ) : null}

              {selected.type === 'text' ? (
                <>
                  <div>
                    <Label>Text</Label>
                    <Input value={selected.text ?? ''} onChange={(e) => updateElement({ text: e.target.value })} />
                  </div>
                  <Row gap={10}>
                    <div style={{ flex: 1 }}>
                      <Label>Font Size</Label>
                      <Input type="number" value={selected.fontSize ?? 32} onChange={(e) => updateElement({ fontSize: Number(e.target.value) })} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <Label>Align</Label>
                      <Input value={selected.align ?? 'center'} onChange={(e) => updateElement({ align: e.target.value as any })} />
                    </div>
                  </Row>
                  <div>
                    <Label>Fill</Label>
                    <Input value={selected.fill ?? '#ffffff'} onChange={(e) => updateElement({ fill: e.target.value })} />
                  </div>
                </>
              ) : null}

              {selected.type === 'rect' ? (
                <>
                  <div>
                    <Label>Fill</Label>
                    <Input value={selected.fill ?? '#1f2a44'} onChange={(e) => updateElement({ fill: e.target.value })} />
                  </div>
                  <Row gap={10}>
                    <div style={{ flex: 1 }}>
                      <Label>Stroke</Label>
                      <Input value={selected.stroke ?? '#3b5b8a'} onChange={(e) => updateElement({ stroke: e.target.value })} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <Label>Stroke W</Label>
                      <Input type="number" value={selected.strokeWidth ?? 2} onChange={(e) => updateElement({ strokeWidth: Number(e.target.value) })} />
                    </div>
                  </Row>
                  <div>
                    <Label>Radius</Label>
                    <Input type="number" value={selected.radius ?? 0} onChange={(e) => updateElement({ radius: Number(e.target.value) })} />
                  </div>
                </>
              ) : null}

              {selected.type === 'image' ? (
                <>
                  <div style={{ color: 'var(--muted)', fontSize: 13, lineHeight: 1.6 }}>
                    الصورة تُحفظ داخل المشروع كـ DataURL في هذا الـ MVP (للسهولة). لاحقاً يمكن تحويلها إلى Asset library.
                  </div>
                </>
              ) : null}

              <Divider />

              <div>
                <Label>Binding Key (اختياري)</Label>
                <Input
                  placeholder="مثال: name"
                  value={selected.bindingKey ?? ''}
                  onChange={(e) => updateElement({ bindingKey: e.target.value })}
                />
                <div style={{ marginTop: 6, color: 'var(--muted)', fontSize: 12, lineHeight: 1.6 }}>
                  إذا تركته فارغاً، سيستخدم المحرّك الصيغة داخل Text: <code>{{'{{field}}'}}</code>.
                </div>
              </div>

              <Button variant="danger" onClick={() => {
                props.onProjectChange({ ...props.project, elements: props.project.elements.filter((e) => e.id !== selected.id) });
                setSelectedId(null);
              }}>
                حذف العنصر
              </Button>
            </div>
          )}
        </Panel>
      </div>

      {/* Status bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '6px 14px',
        borderTop: '1px solid var(--line)',
        color: 'var(--muted)',
        fontSize: 12,
        background: 'rgba(0,0,0,.22)',
      }}>
        <div>{status}</div>
        <div>Duplicate: <span className="kbd">Ctrl</span> + <span className="kbd">D</span></div>
      </div>
    </div>
  );
}

const iconBtnStyle: React.CSSProperties = {
  border: '1px solid var(--line)',
  background: 'rgba(255,255,255,.03)',
  color: 'var(--text)',
  borderRadius: 10,
  padding: '6px 8px',
  cursor: 'pointer',
};

function dataUrlToArrayBuffer(dataUrl: string): ArrayBuffer {
  const base64 = dataUrl.split(',')[1] ?? '';
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer;
}

function sanitizeFileName(name: string) {
  return String(name).trim().replace(/[<>:"/\\|?*]+/g, '_').replace(/\s+/g, ' ').slice(0, 120);
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });
}
