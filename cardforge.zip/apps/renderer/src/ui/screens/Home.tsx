import React from 'react';
import { Button, Panel } from '../components/Ui';

export function Home(props: { onNew: () => void; onOpen: () => void }) {
  return (
    <div style={{ height: '100vh', display: 'grid', placeItems: 'center', padding: 24 }}>
      <div style={{ width: 980, display: 'grid', gridTemplateColumns: '1.2fr .8fr', gap: 18 }}>
        <Panel>
          <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: .2 }}>CardForge</div>
          <div style={{ marginTop: 8, color: 'var(--muted)', lineHeight: 1.6 }}>
            اصنع بطاقات لعب خلال دقائق: قوالب جاهزة، محرّر سريع، وتصدير بالدفعات من CSV/JSON.
            <div style={{ marginTop: 10 }}>
              اختصارات مفيدة: <span className="kbd">Ctrl</span> + <span className="kbd">S</span> للحفظ، و
              <span className="kbd" style={{ marginLeft: 6 }}>Ctrl</span> + <span className="kbd">Z</span> للتراجع (قريباً).
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            <Button onClick={props.onNew}>مشروع جديد</Button>
            <Button variant="ghost" onClick={props.onOpen}>فتح مشروع</Button>
          </div>

          <div style={{ marginTop: 18, color: 'var(--muted)', fontSize: 13 }}>
            تلميح: ابدأ بقالب “Fantasy Basic”، ثم جرّب Batch Export بملف CSV صغير.
          </div>
        </Panel>

        <Panel title="لماذا هذا التطبيق؟">
          <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--muted)', lineHeight: 1.8 }}>
            <li>Canvas سريع مع Layers وخصائص واضحة.</li>
            <li>قوالب JSON قابلة للمشاركة.</li>
            <li>ربط نصوص بعناصر بيانات: <code>{{'{{name}}'}}</code> و <code>{{'{{cost}}'}}</code>.</li>
            <li>تصدير دفعات: كل صف = بطاقة.</li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}
