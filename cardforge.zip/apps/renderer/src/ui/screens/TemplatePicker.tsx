import React from 'react';
import { Template } from '@cardforge/core';
import { Button, Panel } from '../components/Ui';

export function TemplatePicker(props: { templates: Template[]; onPick: (t: Template) => void; onBack: () => void }) {
  return (
    <div style={{ height: '100vh', padding: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 700 }}>اختيار قالب</div>
          <div style={{ color: 'var(--muted)', marginTop: 4 }}>ابدأ من قالب جاهز أو من صفحة فارغة.</div>
        </div>
        <Button variant="ghost" onClick={props.onBack}>رجوع</Button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(240px, 1fr))', gap: 14 }}>
        {props.templates.map((t) => (
          <Panel key={t.id} title={t.name} footer={
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: 'var(--muted)', fontSize: 12 }}>{t.size.w}×{t.size.h}px</span>
              <Button onClick={() => props.onPick(t)}>اختيار</Button>
            </div>
          }>
            <div style={{ color: 'var(--muted)', lineHeight: 1.6 }}>{t.description}</div>
          </Panel>
        ))}
      </div>
    </div>
  );
}
