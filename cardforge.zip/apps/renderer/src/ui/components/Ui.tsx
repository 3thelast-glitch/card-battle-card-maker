import React from 'react';

export function Panel(props: { title?: string; children: React.ReactNode; footer?: React.ReactNode }) {
  return (
    <div style={{
      background: 'var(--panel)',
      border: '1px solid var(--line)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0,
    }}>
      {props.title ? (
        <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--line)', color: 'var(--muted)', fontSize: 13 }}>
          {props.title}
        </div>
      ) : null}
      <div style={{ padding: 12, minHeight: 0, overflow: 'auto' }}>{props.children}</div>
      {props.footer ? (
        <div style={{ padding: 10, borderTop: '1px solid var(--line)', background: 'rgba(0,0,0,.12)' }}>
          {props.footer}
        </div>
      ) : null}
    </div>
  );
}

export function Button(props: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'ghost' | 'danger' }) {
  const variant = props.variant ?? 'primary';
  const bg =
    variant === 'primary' ? 'rgba(94,234,212,.16)' :
    variant === 'danger' ? 'rgba(251,113,133,.14)' :
    'transparent';
  const br =
    variant === 'primary' ? 'rgba(94,234,212,.35)' :
    variant === 'danger' ? 'rgba(251,113,133,.35)' :
    'var(--line)';

  return (
    <button
      {...props}
      style={{
        padding: '10px 12px',
        borderRadius: 12,
        border: `1px solid ${br}`,
        background: bg,
        color: 'var(--text)',
        cursor: 'pointer',
        transition: 'transform .05s ease',
        ...props.style,
      }}
      onMouseDown={(e) => {
        (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(1px)';
        props.onMouseDown?.(e);
      }}
      onMouseUp={(e) => {
        (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0px)';
        props.onMouseUp?.(e);
      }}
    />
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      style={{
        width: '100%',
        padding: '9px 10px',
        borderRadius: 10,
        border: '1px solid var(--line)',
        background: 'rgba(255,255,255,.03)',
        color: 'var(--text)',
        outline: 'none',
        ...props.style,
      }}
    />
  );
}

export function Label({ children }: { children: React.ReactNode }) {
  return <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 6 }}>{children}</div>;
}

export function Row({ children, gap = 10 }: { children: React.ReactNode; gap?: number }) {
  return <div style={{ display: 'flex', gap, alignItems: 'center' }}>{children}</div>;
}

export function Divider() {
  return <div style={{ height: 1, background: 'var(--line)', margin: '12px 0' }} />;
}
