# CardForge (MVP)

تطبيق سطح مكتب على Windows لصناعة بطاقات لعب باحترافية: محرّر قابل للتوسّع + Live Preview + قوالب + استيراد CSV/JSON للتصدير بالدفعات.

> التقنية: Electron + React + TypeScript + Konva (Canvas)  
> الفكرة: واجهة تشبه أدوات Tabletop Creator في بساطتها، مع نفَس Squib في ربط البيانات والتصدير بالدفعات، وقوالب جاهزة على طريقة Hearthcards، وبنية قابلة للتوسع مثل Cider.

---

## التشغيل السريع

### المتطلبات
- Node.js (إصدار حديث 18+ أو 20+)
- Windows (مستهدف أساسي)

### تثبيت وتشغيل (وضع التطوير)
```bash
npm install
npm run dev
```

### بناء التطبيق
```bash
npm run dist
```
سيُنتج ذلك حزمة Windows عبر electron-builder داخل:
- `apps/main/dist/` (قد يختلف الاسم حسب البيئة)

---

## ما الذي يقدمه هذا الـ MVP؟

### 1) تدفّق UX (موجود الآن)
- **Home**: إنشاء مشروع جديد / فتح مشروع سابق
- **Template Picker**: اختيار قالب جاهز (JSON) أو قالب فارغ
- **Editor**:
  - لوحة عناصر: Text / Shape (Rect) / Image
  - Canvas مع Grid و Snap-to-grid
  - Layers panel
  - Properties panel
- **Export**: PNG (لكل بطاقة) + Batch Export من CSV/JSON

### 2) نظام القوالب (Templates)
- القوالب موجودة في مجلد `templates/` بصيغة JSON.
- القالب يصف:
  - أبعاد البطاقة
  - عناصر افتراضية
  - تعريف الحقول القابلة للربط بالبيانات (Bindings)

### 3) استيراد CSV/JSON والتصدير بالدفعات
- استيراد CSV (PapaParse) أو JSON (Array).
- كل صف بيانات يُطبَّق على القالب عبر الصيغة:
  - `{{fieldName}}` داخل نصوص عناصر Text
- ثم يتم التصدير تلقائياً إلى ملفات PNG لكل صف.

---

## قرارات تقنية مختصرة

- **Konva**: يعطي Canvas سريع مع طبقات وسحب/تحديد/تحويل، ويُسهّل التصدير إلى PNG.
- **فصل الطبقات**:
  - `packages/core`: نماذج البيانات + تطبيق الـ bindings + عمليات التحويل الأساسية
  - `packages/storage`: التخزين المحلي (JSON في AppData) + فتح/حفظ
  - `apps/renderer`: واجهة React
  - `apps/main`: Electron main + IPC للحفظ و dialogs
- **IPC بسيط وآمن** عبر `preload` و `contextBridge`.

---

## بنية المجلدات

```
cardforge/
  apps/
    main/        # Electron main + preload + packaging
    renderer/    # React UI (Vite) + Konva editor
  packages/
    core/        # نماذج المشروع + محرك bindings + utils
    storage/     # حفظ/فتح المشاريع (JSON) + مسارات AppData
  templates/     # قوالب جاهزة بصيغة JSON
  docs/          # ملاحظات وخطة تطوير
```

---

## خارطة الطريق

### الإصدار 1 (MVP) ✅
- محرر + حفظ/فتح + قوالب أساسية + Export PNG + Batch Export CSV/JSON

### الإصدار 2
- SVG/PDF export (اختياري) + طباعة صفحات (imposition)
- Align/Distribute + اختصارات أكثر + Undo/Redo كامل
- مكتبة أصول (صور/أيقونات) + بحث

### الإصدار 3
- Cloud Sync + Team templates
- محرّك Layout أكثر ذكاءً (Auto-fit, text overflow rules)
- إضافات (Plugins) للـ renderers والـ exporters

---

## ملاحظة
هذا مشروع مبدئي كامل ومشغّل، لكنه مقصود ليكون **نقطة انطلاق قوية**. مثل القهوة: أول رشفة تعدك بالكثير، ثم تبني عليها ما تشاء.
