import { Project } from '@cardforge/core';

export const storage = {
  stringifyProject(p: Project): string {
    const withUpdated = {
      ...p,
      meta: { ...p.meta, updatedAt: new Date().toISOString() },
    };
    return JSON.stringify(withUpdated, null, 2);
  },

  parseProject(text: string): Project {
    const parsed = JSON.parse(text) as Project;
    // soft validation
    if (!parsed?.templateId || !Array.isArray(parsed.elements)) {
      throw new Error('Invalid project file');
    }
    if (!parsed.meta) {
      parsed.meta = { name: 'Imported', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    }
    return parsed;
  },
};
