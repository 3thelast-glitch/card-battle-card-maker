import type { Project, Template } from './model';

export function createEmptyProjectFromTemplate(tpl: Template): Project {
  const now = new Date().toISOString();
  return {
    meta: {
      name: 'Untitled Project',
      createdAt: now,
      updatedAt: now,
    },
    templateId: tpl.id,
    elements: tpl.elements.map((e) => ({ ...e })), // clone
  };
}
