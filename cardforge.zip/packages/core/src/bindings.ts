import type { ElementModel } from './model';

/**
 * Apply data bindings to element text using:
 * - element.bindingKey (if present): replace entire text with row[bindingKey]
 * - or {{field}} patterns inside TextElement.text
 */
export function applyBindingsToElements(elements: ElementModel[], row: Record<string, any>): ElementModel[] {
  return elements.map((el) => {
    if (el.type !== 'text') return el;

    const bindingKey = el.bindingKey?.trim();
    if (bindingKey) {
      const v = row[bindingKey];
      return { ...el, text: v === undefined || v === null ? '' : String(v) };
    }

    const text = el.text ?? '';
    const next = text.replace(/\{\{\s*([a-zA-Z0-9_\.\-]+)\s*\}\}/g, (_m, key) => {
      const v = resolve(row, key);
      return v === undefined || v === null ? '' : String(v);
    });

    return { ...el, text: next };
  });
}

function resolve(obj: any, path: string) {
  // supports dot paths: stats.attack
  const parts = String(path).split('.');
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}
