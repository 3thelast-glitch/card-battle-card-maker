import { nanoid } from 'nanoid';

export function createId() {
  return nanoid(10);
}

export function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}
