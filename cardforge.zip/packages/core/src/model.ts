export type ElementType = 'text' | 'rect' | 'image';

export type BaseElement = {
  id: string;
  type: ElementType;
  name: string;

  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;

  visible: boolean;

  // Optional data binding
  bindingKey?: string; // if set, override {{field}} parsing
};

export type TextElement = BaseElement & {
  type: 'text';
  text: string;
  fontSize: number;
  fontFamily?: string;
  fill?: string;
  align?: 'left' | 'center' | 'right';
};

export type RectElement = BaseElement & {
  type: 'rect';
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  radius?: number;
};

export type ImageElement = BaseElement & {
  type: 'image';
  src: string; // DataURL in MVP
  crop?: null | { x: number; y: number; w: number; h: number };
};

export type ElementModel = TextElement | RectElement | ImageElement;

export type Template = {
  id: string;
  name: string;
  description: string;
  size: { w: number; h: number };
  background?: string;
  elements: ElementModel[];
};

export type Project = {
  meta: {
    name: string;
    createdAt: string;
    updatedAt: string;
    filePath?: string;
  };
  templateId: string;
  elements: ElementModel[];
};
